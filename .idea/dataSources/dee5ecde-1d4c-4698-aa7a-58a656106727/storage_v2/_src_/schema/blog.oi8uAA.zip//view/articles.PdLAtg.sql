create definer = root@`%` view articles as
select `blog`.`article`.`user_id`     AS `user_id`,
       `blog`.`article`.`id`          AS `article_id`,
       `blog`.`article`.`title`       AS `title`,
       `blog`.`article`.`content`     AS `content`,
       `blog`.`article`.`views`       AS `views`,
       `blog`.`article`.`create_time` AS `create_time`,
       `blog`.`tag`.`name`            AS `tag_name`,
       `blog`.`tag`.`id`              AS `tag_id`,
       `blog`.`category`.`name`       AS `category_name`,
       `blog`.`category`.`id`         AS `category_id`
from (((`blog`.`category` join `blog`.`article` on ((`blog`.`article`.`category_id` = `blog`.`category`.`id`))) left join `blog`.`article_tag` on ((`blog`.`article_tag`.`article_id` = `blog`.`article`.`id`)))
         left join `blog`.`tag` on ((`blog`.`article_tag`.`tag_id` = `blog`.`tag`.`id`)));

-- comment on column articles.tag_name not supported: tag不可重复，若用户输入的标签已存在，则在article_tag表中使tag_id指向已存在的那个id

